import{r as o}from"./index-2a7246bb.js";var a=Boolean(globalThis==null?void 0:globalThis.document)?o.useLayoutEffect:o.useEffect;export{a as u};
//# sourceMappingURL=index-4ad6bebe.js.map
