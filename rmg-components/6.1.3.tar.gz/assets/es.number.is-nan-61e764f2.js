var N=Object.defineProperty;var a=(r,t)=>N(r,"name",{value:t,configurable:!0});import{_ as e}from"./es.object.get-own-property-descriptor-2f3bcc00.js";var i=e;i({target:"Number",stat:!0},{isNaN:a(function(t){return t!=t},"isNaN")});
//# sourceMappingURL=es.number.is-nan-61e764f2.js.map
