var m=Object.defineProperty;var o=(t,r)=>m(t,"name",{value:r,configurable:!0});import{j as e}from"./jsx-runtime-ad6454d2.js";import{R as n}from"./rmg-label-f289b973.js";import{R as a}from"./rmg-debounced-input-a4d6e4e7.js";import"./index-2a7246bb.js";import"./es.object.get-own-property-descriptor-2f3bcc00.js";import"./chunk-JSSKUSQH-18a3c636.js";import"./index-348bd907.js";import"./index-7822c6a4.js";import"./chunk-QEVFQ4EU-457e66a5.js";import"./chunk-QJA5SDDN-5308f814.js";const f={parameters:{storySource:{source:`import { RmgLabel } from './rmg-label';
import { RmgDebouncedInput } from '../rmg-debounced-input';

export default {
    title: 'RmgLabel',
    component: RmgLabel,
};

export const Basic = () => {
    return (
        <RmgLabel label="Basic input">
            <RmgDebouncedInput />
        </RmgLabel>
    );
};
`,locationsMap:{basic:{startLoc:{col:21,line:9},endLoc:{col:1,line:15},startBody:{col:21,line:9},endBody:{col:1,line:15}}}}},title:"RmgLabel",component:n},B=o(()=>e(n,{label:"Basic input",children:e(a,{})}),"Basic"),x=["Basic"];export{B as Basic,x as __namedExportsOrder,f as default};
//# sourceMappingURL=rmg-label.stories-23d3d278.js.map
