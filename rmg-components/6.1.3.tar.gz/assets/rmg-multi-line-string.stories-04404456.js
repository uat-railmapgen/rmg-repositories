var r=Object.defineProperty;var n=(t,e)=>r(t,"name",{value:e,configurable:!0});import{j as o}from"./jsx-runtime-ad6454d2.js";import{R as i}from"./rmg-multi-line-string-76ea44f6.js";import"./index-2a7246bb.js";import"./es.object.get-own-property-descriptor-2f3bcc00.js";import"./chunk-QEVFQ4EU-457e66a5.js";const d={parameters:{storySource:{source:`import { RmgMultiLineString } from './rmg-multi-line-string';

export default {
    title: 'RmgMultiLineString',
    component: RmgMultiLineString,
};

export const Basic = () => {
    const text = 'First line\\nSecond line\\nThird line';
    return <RmgMultiLineString text={text} delimiter={'\\n'} />;
};
`,locationsMap:{basic:{startLoc:{col:21,line:8},endLoc:{col:1,line:11},startBody:{col:21,line:8},endBody:{col:1,line:11}}}}},title:"RmgMultiLineString",component:i},p=n(()=>o(i,{text:`First line
Second line
Third line`,delimiter:`
`}),"Basic"),u=["Basic"];export{p as Basic,u as __namedExportsOrder,d as default};
//# sourceMappingURL=rmg-multi-line-string.stories-04404456.js.map
