import{a1 as r,a0 as t,aB as a,j as o}from"./es.object.get-own-property-descriptor-2f3bcc00.js";var s=r,p=t,g=a,l=o,e=RegExp.prototype,f=s&&l(function(){return Object.getOwnPropertyDescriptor(e,"flags").get.call({dotAll:!0,sticky:!0})!=="sy"});f&&p.f(e,"flags",{configurable:!0,get:g});
//# sourceMappingURL=es.regexp.flags-d6dcc548.js.map
