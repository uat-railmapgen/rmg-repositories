var a=Object.defineProperty;var e=(r,t)=>a(r,"name",{value:t,configurable:!0});import{r as i}from"./index-2a7246bb.js";function o(r){return i.Children.toArray(r).filter(t=>i.isValidElement(t))}e(o,"getValidChildren");export{o as g};
//# sourceMappingURL=index-71b8f272.js.map
