var a=Object.defineProperty;var o=(t,n)=>a(t,"name",{value:n,configurable:!0});import{j as e}from"./jsx-runtime-ad6454d2.js";import{R as r}from"./rmg-card-ee8a8432.js";import"./index-2a7246bb.js";import"./es.object.get-own-property-descriptor-2f3bcc00.js";import"./chunk-QEVFQ4EU-457e66a5.js";import"./chunk-MPFPK3CX-3bead6a5.js";const C={parameters:{storySource:{source:`import React from 'react';
import { RmgCard } from './rmg-card';

export default {
    title: 'RmgCard',
    component: RmgCard,
};

export const Basic = () => <RmgCard>Content</RmgCard>;
`,locationsMap:{basic:{startLoc:{col:21,line:9},endLoc:{col:53,line:9},startBody:{col:21,line:9},endBody:{col:53,line:9}}}}},title:"RmgCard",component:r},g=o(()=>e(r,{children:"Content"}),"Basic"),R=["Basic"];export{g as Basic,R as __namedExportsOrder,C as default};
//# sourceMappingURL=rmg-card.stories-dbb1a9e8.js.map
