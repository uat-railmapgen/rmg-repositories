var r=Object.defineProperty;var o=(n,t)=>r(n,"name",{value:t,configurable:!0});import{ap as e,aq as a}from"./es.object.get-own-property-descriptor-2f3bcc00.js";var c=e,i=a;c("Map",function(n){return o(function(){return n(this,arguments.length?arguments[0]:void 0)},"Map")},i);
//# sourceMappingURL=es.map-c78d993e.js.map
