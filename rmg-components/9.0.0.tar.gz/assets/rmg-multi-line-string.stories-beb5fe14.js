import{j as s}from"./jsx-runtime-ffb262ed.js";import{R as n}from"./rmg-multi-line-string-398937ab.js";import"./index-76fb7be0.js";import"./_commonjsHelpers-de833af9.js";import"./chunk-ZJJGQIVY-4bd0a974.js";import"./emotion-use-insertion-effect-with-fallbacks.browser.esm-55b21f7f.js";const u={title:"RmgMultiLineString",component:n},t=()=>{const o=`First line
Second line
Third line`;return s.jsx(n,{text:o,delimiter:`
`})};var e,r,i;t.parameters={...t.parameters,docs:{...(e=t.parameters)==null?void 0:e.docs,source:{originalSource:`() => {
  const text = 'First line\\nSecond line\\nThird line';
  return <RmgMultiLineString text={text} delimiter={'\\n'} />;
}`,...(i=(r=t.parameters)==null?void 0:r.docs)==null?void 0:i.source}}};const g=["Basic"];export{t as Basic,g as __namedExportsOrder,u as default};
//# sourceMappingURL=rmg-multi-line-string.stories-beb5fe14.js.map
