import{r as o}from"./index-76fb7be0.js";var a=globalThis!=null&&globalThis.document?o.useLayoutEffect:o.useEffect;export{a as u};
//# sourceMappingURL=index-3e7aa64e.js.map
