function e(t,o){return e=Object.setPrototypeOf?Object.setPrototypeOf.bind():function(r,n){return r.__proto__=n,r},e(t,o)}function c(t,o){t.prototype=Object.create(o.prototype),t.prototype.constructor=t,e(t,o)}export{c as _,e as a};
//# sourceMappingURL=inheritsLoose-c82a83d4.js.map
