import{j as e}from"./jsx-runtime-ffb262ed.js";import{R as s}from"./rmg-label-85d4b295.js";import{R as a}from"./rmg-debounced-input-ab04b406.js";import"./index-76fb7be0.js";import"./_commonjsHelpers-de833af9.js";import"./chunk-XRMX4GAI-f266e033.js";import"./index-7abe7895.js";import"./index-17e33fe9.js";import"./chunk-ZJJGQIVY-4bd0a974.js";import"./emotion-use-insertion-effect-with-fallbacks.browser.esm-55b21f7f.js";import"./chunk-QJA5SDDN-601f6f7e.js";const L={title:"RmgLabel",component:s},r=()=>e.jsx(s,{label:"Basic input",children:e.jsx(a,{})});var t,o,m;r.parameters={...r.parameters,docs:{...(t=r.parameters)==null?void 0:t.docs,source:{originalSource:`() => {
  return <RmgLabel label="Basic input">
            <RmgDebouncedInput />
        </RmgLabel>;
}`,...(m=(o=r.parameters)==null?void 0:o.docs)==null?void 0:m.source}}};const f=["Basic"];export{r as Basic,f as __namedExportsOrder,L as default};
//# sourceMappingURL=rmg-label.stories-9493be67.js.map
