import{j as t}from"./jsx-runtime-ffb262ed.js";import{R as o}from"./rmg-enriched-button-67ee038a.js";import{H as m}from"./chunk-3ASUQ6PA-664b249f.js";import"./index-76fb7be0.js";import"./_commonjsHelpers-de833af9.js";import"./chunk-ZJJGQIVY-4bd0a974.js";import"./emotion-use-insertion-effect-with-fallbacks.browser.esm-55b21f7f.js";import"./chunk-UVUR7MCU-5ad2b195.js";import"./index-7abe7895.js";import"./emotion-react.browser.esm-583f468d.js";import"./index-17e33fe9.js";import"./index-e1b4ee4c.js";const j={title:"RmgEnrichedButton",component:o},r=()=>t.jsxs(m,{children:[t.jsx(o,{variant:"solid",colorScheme:"primary",primaryText:"Project 123",secondaryText:"Last modified: 10 mins ago"}),t.jsx(o,{primaryText:"Kwun Tong Line",secondaryText:"by: wongchito"})]});var e,i,n;r.parameters={...r.parameters,docs:{...(e=r.parameters)==null?void 0:e.docs,source:{originalSource:`() => {
  return <HStack>
            <RmgEnrichedButton variant="solid" colorScheme="primary" primaryText="Project 123" secondaryText="Last modified: 10 mins ago" />
            <RmgEnrichedButton primaryText="Kwun Tong Line" secondaryText="by: wongchito" />
        </HStack>;
}`,...(n=(i=r.parameters)==null?void 0:i.docs)==null?void 0:n.source}}};const B=["Basic"];export{r as Basic,B as __namedExportsOrder,j as default};
//# sourceMappingURL=rmg-enriched-button.stories-f49b1b1b.js.map
