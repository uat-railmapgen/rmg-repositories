import{r as o}from"./index-76fb7be0.js";function e(r,n){if(r!=null){if(typeof r=="function"){r(n);return}try{r.current=n}catch{throw new Error(`Cannot assign value '${n}' to ref '${r}'`)}}}function u(...r){return n=>{r.forEach(t=>{e(t,n)})}}function c(...r){return o.useMemo(()=>u(...r),r)}export{u as m,c as u};
//# sourceMappingURL=index-17e33fe9.js.map
