import{r as o}from"./index-76fb7be0.js";function u(r,n){if(r!=null){if(typeof r=="function"){r(n);return}try{r.current=n}catch{throw new Error(`Cannot assign value '${n}' to ref '${r}'`)}}}function i(...r){return o.useMemo(()=>r.every(n=>n==null)?null:n=>{r.forEach(t=>{t&&u(t,n)})},r)}export{i as u};
//# sourceMappingURL=chunk-QJA5SDDN-601f6f7e.js.map
