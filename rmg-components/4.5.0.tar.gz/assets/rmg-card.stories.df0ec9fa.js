var a=Object.defineProperty;var o=(t,n)=>a(t,"name",{value:n,configurable:!0});import{R as r}from"./rmg-card.57613f18.js";import{j as e}from"./jsx-runtime.f29acd6c.js";import"./index.esm.8968f01e.js";import"./iframe.8b94e34e.js";import"./index.esm.f10cda7a.js";const l={parameters:{storySource:{source:`import React from 'react';
import { RmgCard } from './rmg-card';

export default {
    title: 'RmgCard',
    component: RmgCard,
};

export const Basic = () => <RmgCard>Content</RmgCard>;
`,locationsMap:{basic:{startLoc:{col:21,line:9},endLoc:{col:53,line:9},startBody:{col:21,line:9},endBody:{col:53,line:9}}}}},title:"RmgCard",component:r},C=o(()=>e(r,{children:"Content"}),"Basic"),g=["Basic"];export{C as Basic,g as __namedExportsOrder,l as default};
//# sourceMappingURL=rmg-card.stories.df0ec9fa.js.map
