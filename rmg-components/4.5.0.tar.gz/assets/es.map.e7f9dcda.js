var r=Object.defineProperty;var o=(n,t)=>r(n,"name",{value:t,configurable:!0});import{k as e,n as c}from"./iframe.8b94e34e.js";var i=e,l=c;i("Map",function(n){return o(function(){return n(this,arguments.length?arguments[0]:void 0)},"Map")},l);
//# sourceMappingURL=es.map.e7f9dcda.js.map
