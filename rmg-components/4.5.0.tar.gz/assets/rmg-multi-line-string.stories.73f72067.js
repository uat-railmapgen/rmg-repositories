var r=Object.defineProperty;var n=(t,e)=>r(t,"name",{value:e,configurable:!0});import{R as i}from"./rmg-multi-line-string.7d3ffdbf.js";import{j as o}from"./jsx-runtime.f29acd6c.js";import"./index.esm.f10cda7a.js";import"./index.esm.8968f01e.js";import"./iframe.8b94e34e.js";const d={parameters:{storySource:{source:`import { RmgMultiLineString } from './rmg-multi-line-string';

export default {
    title: 'RmgMultiLineString',
    component: RmgMultiLineString,
};

export const Basic = () => {
    const text = 'First line\\nSecond line\\nThird line';
    return <RmgMultiLineString text={text} delimiter={'\\n'} />;
};
`,locationsMap:{basic:{startLoc:{col:21,line:8},endLoc:{col:1,line:11},startBody:{col:21,line:8},endBody:{col:1,line:11}}}}},title:"RmgMultiLineString",component:i},p=n(()=>o(i,{text:`First line
Second line
Third line`,delimiter:`
`}),"Basic"),u=["Basic"];export{p as Basic,u as __namedExportsOrder,d as default};
//# sourceMappingURL=rmg-multi-line-string.stories.73f72067.js.map
