var e=Object.defineProperty;var o=(n,i)=>e(n,"name",{value:i,configurable:!0});import{w as l,d as b,y as s,u as v}from"./iframe.8b94e34e.js";var r=o(function(i){var t=Array.isArray(i)?i:[i];t.forEach(h)},"clearStyles"),h=o(function(i){var t=l.document.getElementById(i);t&&t.parentElement&&t.parentElement.removeChild(t)},"clearStyle"),y=o(function(i,t){var a=l.document.getElementById(i);if(a)a.innerHTML!==t&&(a.innerHTML=t);else{var p=l.document.createElement("style");p.setAttribute("id",i),p.innerHTML=t,l.document.head.appendChild(p)}},"addOutlineStyles"),f="outline",x;function g(n,i){return i||(i=n.slice(0)),Object.freeze(Object.defineProperties(n,{raw:{value:Object.freeze(i)}}))}o(g,"_taggedTemplateLiteral");function S(n){return b(x||(x=g([`
    `,` body {
      outline: 1px solid #2980b9 !important;
    }

    `,` article {
      outline: 1px solid #3498db !important;
    }

    `,` nav {
      outline: 1px solid #0088c3 !important;
    }

    `,` aside {
      outline: 1px solid #33a0ce !important;
    }

    `,` section {
      outline: 1px solid #66b8da !important;
    }

    `,` header {
      outline: 1px solid #99cfe7 !important;
    }

    `,` footer {
      outline: 1px solid #cce7f3 !important;
    }

    `,` h1 {
      outline: 1px solid #162544 !important;
    }

    `,` h2 {
      outline: 1px solid #314e6e !important;
    }

    `,` h3 {
      outline: 1px solid #3e5e85 !important;
    }

    `,` h4 {
      outline: 1px solid #449baf !important;
    }

    `,` h5 {
      outline: 1px solid #c7d1cb !important;
    }

    `,` h6 {
      outline: 1px solid #4371d0 !important;
    }

    `,` main {
      outline: 1px solid #2f4f90 !important;
    }

    `,` address {
      outline: 1px solid #1a2c51 !important;
    }

    `,` div {
      outline: 1px solid #036cdb !important;
    }

    `,` p {
      outline: 1px solid #ac050b !important;
    }

    `,` hr {
      outline: 1px solid #ff063f !important;
    }

    `,` pre {
      outline: 1px solid #850440 !important;
    }

    `,` blockquote {
      outline: 1px solid #f1b8e7 !important;
    }

    `,` ol {
      outline: 1px solid #ff050c !important;
    }

    `,` ul {
      outline: 1px solid #d90416 !important;
    }

    `,` li {
      outline: 1px solid #d90416 !important;
    }

    `,` dl {
      outline: 1px solid #fd3427 !important;
    }

    `,` dt {
      outline: 1px solid #ff0043 !important;
    }

    `,` dd {
      outline: 1px solid #e80174 !important;
    }

    `,` figure {
      outline: 1px solid #ff00bb !important;
    }

    `,` figcaption {
      outline: 1px solid #bf0032 !important;
    }

    `,` table {
      outline: 1px solid #00cc99 !important;
    }

    `,` caption {
      outline: 1px solid #37ffc4 !important;
    }

    `,` thead {
      outline: 1px solid #98daca !important;
    }

    `,` tbody {
      outline: 1px solid #64a7a0 !important;
    }

    `,` tfoot {
      outline: 1px solid #22746b !important;
    }

    `,` tr {
      outline: 1px solid #86c0b2 !important;
    }

    `,` th {
      outline: 1px solid #a1e7d6 !important;
    }

    `,` td {
      outline: 1px solid #3f5a54 !important;
    }

    `,` col {
      outline: 1px solid #6c9a8f !important;
    }

    `,` colgroup {
      outline: 1px solid #6c9a9d !important;
    }

    `,` button {
      outline: 1px solid #da8301 !important;
    }

    `,` datalist {
      outline: 1px solid #c06000 !important;
    }

    `,` fieldset {
      outline: 1px solid #d95100 !important;
    }

    `,` form {
      outline: 1px solid #d23600 !important;
    }

    `,` input {
      outline: 1px solid #fca600 !important;
    }

    `,` keygen {
      outline: 1px solid #b31e00 !important;
    }

    `,` label {
      outline: 1px solid #ee8900 !important;
    }

    `,` legend {
      outline: 1px solid #de6d00 !important;
    }

    `,` meter {
      outline: 1px solid #e8630c !important;
    }

    `,` optgroup {
      outline: 1px solid #b33600 !important;
    }

    `,` option {
      outline: 1px solid #ff8a00 !important;
    }

    `,` output {
      outline: 1px solid #ff9619 !important;
    }

    `,` progress {
      outline: 1px solid #e57c00 !important;
    }

    `,` select {
      outline: 1px solid #e26e0f !important;
    }

    `,` textarea {
      outline: 1px solid #cc5400 !important;
    }

    `,` details {
      outline: 1px solid #33848f !important;
    }

    `,` summary {
      outline: 1px solid #60a1a6 !important;
    }

    `,` command {
      outline: 1px solid #438da1 !important;
    }

    `,` menu {
      outline: 1px solid #449da6 !important;
    }

    `,` del {
      outline: 1px solid #bf0000 !important;
    }

    `,` ins {
      outline: 1px solid #400000 !important;
    }

    `,` img {
      outline: 1px solid #22746b !important;
    }

    `,` iframe {
      outline: 1px solid #64a7a0 !important;
    }

    `,` embed {
      outline: 1px solid #98daca !important;
    }

    `,` object {
      outline: 1px solid #00cc99 !important;
    }

    `,` param {
      outline: 1px solid #37ffc4 !important;
    }

    `,` video {
      outline: 1px solid #6ee866 !important;
    }

    `,` audio {
      outline: 1px solid #027353 !important;
    }

    `,` source {
      outline: 1px solid #012426 !important;
    }

    `,` canvas {
      outline: 1px solid #a2f570 !important;
    }

    `,` track {
      outline: 1px solid #59a600 !important;
    }

    `,` map {
      outline: 1px solid #7be500 !important;
    }

    `,` area {
      outline: 1px solid #305900 !important;
    }

    `,` a {
      outline: 1px solid #ff62ab !important;
    }

    `,` em {
      outline: 1px solid #800b41 !important;
    }

    `,` strong {
      outline: 1px solid #ff1583 !important;
    }

    `,` i {
      outline: 1px solid #803156 !important;
    }

    `,` b {
      outline: 1px solid #cc1169 !important;
    }

    `,` u {
      outline: 1px solid #ff0430 !important;
    }

    `,` s {
      outline: 1px solid #f805e3 !important;
    }

    `,` small {
      outline: 1px solid #d107b2 !important;
    }

    `,` abbr {
      outline: 1px solid #4a0263 !important;
    }

    `,` q {
      outline: 1px solid #240018 !important;
    }

    `,` cite {
      outline: 1px solid #64003c !important;
    }

    `,` dfn {
      outline: 1px solid #b4005a !important;
    }

    `,` sub {
      outline: 1px solid #dba0c8 !important;
    }

    `,` sup {
      outline: 1px solid #cc0256 !important;
    }

    `,` time {
      outline: 1px solid #d6606d !important;
    }

    `,` code {
      outline: 1px solid #e04251 !important;
    }

    `,` kbd {
      outline: 1px solid #5e001f !important;
    }

    `,` samp {
      outline: 1px solid #9c0033 !important;
    }

    `,` var {
      outline: 1px solid #d90047 !important;
    }

    `,` mark {
      outline: 1px solid #ff0053 !important;
    }

    `,` bdi {
      outline: 1px solid #bf3668 !important;
    }

    `,` bdo {
      outline: 1px solid #6f1400 !important;
    }

    `,` ruby {
      outline: 1px solid #ff7b93 !important;
    }

    `,` rt {
      outline: 1px solid #ff2f54 !important;
    }

    `,` rp {
      outline: 1px solid #803e49 !important;
    }

    `,` span {
      outline: 1px solid #cc2643 !important;
    }

    `,` br {
      outline: 1px solid #db687d !important;
    }

    `,` wbr {
      outline: 1px solid #db175b !important;
    }`])),n,n,n,n,n,n,n,n,n,n,n,n,n,n,n,n,n,n,n,n,n,n,n,n,n,n,n,n,n,n,n,n,n,n,n,n,n,n,n,n,n,n,n,n,n,n,n,n,n,n,n,n,n,n,n,n,n,n,n,n,n,n,n,n,n,n,n,n,n,n,n,n,n,n,n,n,n,n,n,n,n,n,n,n,n,n,n,n,n,n,n,n,n,n,n,n,n,n,n)}o(S,"outlineCSS");var O=o(function(i,t){var a=t.globals,p=a[f]===!0,u=t.viewMode==="docs",m=s(function(){var d=u?"#anchor--".concat(t.id," .docs-story"):".sb-show-main";return S(d)},[t]);return v(function(){var d=u?"addon-outline-docs-".concat(t.id):"addon-outline";return p?y(d,m):r(d),function(){r(d)}},[p,m,t]),i()},"withOutline");function w(n,i,t){return i in n?Object.defineProperty(n,i,{value:t,enumerable:!0,configurable:!0,writable:!0}):n[i]=t,n}o(w,"_defineProperty");var M=[O],_=w({},f,!1);export{M as decorators,_ as globals};
//# sourceMappingURL=preview.65aef623.js.map
