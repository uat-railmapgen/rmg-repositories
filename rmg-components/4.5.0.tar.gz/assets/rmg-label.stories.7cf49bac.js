var m=Object.defineProperty;var o=(t,r)=>m(t,"name",{value:r,configurable:!0});import{R as n}from"./rmg-label.0af69304.js";import{R as a}from"./rmg-debounced-input.a0ca4f6f.js";import{j as e}from"./jsx-runtime.f29acd6c.js";import"./index.esm.c4f03bd3.js";import"./index.esm.8968f01e.js";import"./iframe.8b94e34e.js";import"./index.esm.ce0d501f.js";import"./index.esm.0f20b62c.js";const R={parameters:{storySource:{source:`import { RmgLabel } from './rmg-label';
import { RmgDebouncedInput } from '../rmg-debounced-input';

export default {
    title: 'RmgLabel',
    component: RmgLabel,
};

export const Basic = () => {
    return (
        <RmgLabel label="Basic input">
            <RmgDebouncedInput />
        </RmgLabel>
    );
};
`,locationsMap:{basic:{startLoc:{col:21,line:9},endLoc:{col:1,line:15},startBody:{col:21,line:9},endBody:{col:1,line:15}}}}},title:"RmgLabel",component:n},L=o(()=>e(n,{label:"Basic input",children:e(a,{})}),"Basic"),f=["Basic"];export{L as Basic,f as __namedExportsOrder,R as default};
//# sourceMappingURL=rmg-label.stories.7cf49bac.js.map
