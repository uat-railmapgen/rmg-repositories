import{r as e,a1 as t,al as a,E as o}from"./iframe.addee52f.js";var s=e,l=t,p=a,g=o,r=RegExp.prototype,f=s&&g(function(){return Object.getOwnPropertyDescriptor(r,"flags").get.call({dotAll:!0,sticky:!0})!=="sy"});f&&l.f(r,"flags",{configurable:!0,get:p});
//# sourceMappingURL=es.regexp.flags.f5b32da8.js.map
