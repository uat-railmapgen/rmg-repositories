var r=Object.defineProperty;var o=(n,t)=>r(n,"name",{value:t,configurable:!0});import{k as e,n as c}from"./iframe.addee52f.js";var i=e,l=c;i("Map",function(n){return o(function(){return n(this,arguments.length?arguments[0]:void 0)},"Map")},l);
//# sourceMappingURL=es.map.99385ea8.js.map
