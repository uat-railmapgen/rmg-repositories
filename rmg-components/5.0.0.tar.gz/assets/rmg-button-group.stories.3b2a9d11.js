var g=Object.defineProperty;var s=(t,n)=>g(t,"name",{value:n,configurable:!0});import{r as c,a as e,j as a}from"./jsx-runtime.711b232c.js";import{R as l}from"./rmg-button-group.4d538e8c.js";import{F as p,B as i,T as u}from"./index.esm.57965a73.js";import"./iframe.addee52f.js";import"./index.esm.14cd0817.js";import"./index.esm.b2675e82.js";import"./index.esm.63e18ebe.js";const T={parameters:{storySource:{source:`import React, { useState } from 'react';
import { RmgButtonGroup } from './rmg-button-group';
import { Box, Flex, Text } from '@chakra-ui/react';

export default {
    title: 'RmgButtonGroup',
    component: RmgButtonGroup,
};

export const Basic = () => {
    const [singleSelect, setSingleSelect] = useState('gzmtr');
    const [multiSelect, setMultiSelect] = useState(['gzmtr']);

    const selections = [
        { label: 'MTR', value: 'mtr', disabled: true },
        { label: 'GZMTR', value: 'gzmtr' },
        { label: 'SHMetro', value: 'shmetro' },
    ];

    return (
        <Flex>
            <Box w={200}>
                <RmgButtonGroup selections={selections} defaultValue={singleSelect} onChange={setSingleSelect} />
                <RmgButtonGroup
                    selections={selections}
                    defaultValue={multiSelect}
                    onChange={setMultiSelect}
                    multiSelect
                />
            </Box>

            <Box>
                <Text>Single select: {singleSelect}</Text>
                <Text>Multi select: {multiSelect.join(',')}</Text>
            </Box>
        </Flex>
    );
};
`,locationsMap:{basic:{startLoc:{col:21,line:10},endLoc:{col:1,line:38},startBody:{col:21,line:10},endBody:{col:1,line:38}}}}},title:"RmgButtonGroup",component:l},b=s(()=>{const[t,n]=c.exports.useState("gzmtr"),[o,m]=c.exports.useState(["gzmtr"]),r=[{label:"MTR",value:"mtr",disabled:!0},{label:"GZMTR",value:"gzmtr"},{label:"SHMetro",value:"shmetro"}];return e(p,{children:[e(i,{w:200,children:[a(l,{selections:r,defaultValue:t,onChange:n}),a(l,{selections:r,defaultValue:o,onChange:m,multiSelect:!0})]}),e(i,{children:[e(u,{children:["Single select: ",t]}),e(u,{children:["Multi select: ",o.join(",")]})]})]})},"Basic"),G=["Basic"];export{b as Basic,G as __namedExportsOrder,T as default};
//# sourceMappingURL=rmg-button-group.stories.3b2a9d11.js.map
