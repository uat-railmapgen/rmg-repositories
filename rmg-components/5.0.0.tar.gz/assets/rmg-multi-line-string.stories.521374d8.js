var r=Object.defineProperty;var n=(t,e)=>r(t,"name",{value:e,configurable:!0});import{R as i}from"./rmg-multi-line-string.7e974c73.js";import{j as o}from"./jsx-runtime.711b232c.js";import"./index.esm.57965a73.js";import"./index.esm.63e18ebe.js";import"./iframe.addee52f.js";const d={parameters:{storySource:{source:`import { RmgMultiLineString } from './rmg-multi-line-string';

export default {
    title: 'RmgMultiLineString',
    component: RmgMultiLineString,
};

export const Basic = () => {
    const text = 'First line\\nSecond line\\nThird line';
    return <RmgMultiLineString text={text} delimiter={'\\n'} />;
};
`,locationsMap:{basic:{startLoc:{col:21,line:8},endLoc:{col:1,line:11},startBody:{col:21,line:8},endBody:{col:1,line:11}}}}},title:"RmgMultiLineString",component:i},p=n(()=>o(i,{text:`First line
Second line
Third line`,delimiter:`
`}),"Basic"),u=["Basic"];export{p as Basic,u as __namedExportsOrder,d as default};
//# sourceMappingURL=rmg-multi-line-string.stories.521374d8.js.map
