var m=Object.defineProperty;var o=(t,r)=>m(t,"name",{value:r,configurable:!0});import{R as n}from"./rmg-label.f996063b.js";import{R as a}from"./rmg-debounced-input.bcba0963.js";import{j as e}from"./jsx-runtime.711b232c.js";import"./index.esm.0bb6d3ad.js";import"./index.esm.63e18ebe.js";import"./iframe.addee52f.js";import"./index.esm.b2675e82.js";import"./index.esm.1411880c.js";const R={parameters:{storySource:{source:`import { RmgLabel } from './rmg-label';
import { RmgDebouncedInput } from '../rmg-debounced-input';

export default {
    title: 'RmgLabel',
    component: RmgLabel,
};

export const Basic = () => {
    return (
        <RmgLabel label="Basic input">
            <RmgDebouncedInput />
        </RmgLabel>
    );
};
`,locationsMap:{basic:{startLoc:{col:21,line:9},endLoc:{col:1,line:15},startBody:{col:21,line:9},endBody:{col:1,line:15}}}}},title:"RmgLabel",component:n},L=o(()=>e(n,{label:"Basic input",children:e(a,{})}),"Basic"),f=["Basic"];export{L as Basic,f as __namedExportsOrder,R as default};
//# sourceMappingURL=rmg-label.stories.88a22511.js.map
