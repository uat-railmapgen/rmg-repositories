var a=Object.defineProperty;var o=(t,n)=>a(t,"name",{value:n,configurable:!0});import{R as r}from"./rmg-card.ae468c91.js";import{j as e}from"./jsx-runtime.711b232c.js";import"./index.esm.63e18ebe.js";import"./iframe.addee52f.js";import"./index.esm.57965a73.js";const l={parameters:{storySource:{source:`import React from 'react';
import { RmgCard } from './rmg-card';

export default {
    title: 'RmgCard',
    component: RmgCard,
};

export const Basic = () => <RmgCard>Content</RmgCard>;
`,locationsMap:{basic:{startLoc:{col:21,line:9},endLoc:{col:53,line:9},startBody:{col:21,line:9},endBody:{col:53,line:9}}}}},title:"RmgCard",component:r},C=o(()=>e(r,{children:"Content"}),"Basic"),g=["Basic"];export{C as Basic,g as __namedExportsOrder,l as default};
//# sourceMappingURL=rmg-card.stories.484f9ece.js.map
