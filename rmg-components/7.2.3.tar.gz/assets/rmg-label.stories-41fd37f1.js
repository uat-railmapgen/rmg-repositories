import{j as e}from"./jsx-runtime-4ca860c5.js";import{R as s}from"./rmg-label-d74ad164.js";import{R as a}from"./rmg-debounced-input-e0253478.js";import"./index-61bf1805.js";import"./_commonjsHelpers-de833af9.js";import"./chunk-XRMX4GAI-a9941989.js";import"./index-6830816b.js";import"./index-c23131f5.js";import"./chunk-ZJJGQIVY-35f6fb8e.js";import"./emotion-use-insertion-effect-with-fallbacks.browser.esm-5b0f5dab.js";import"./chunk-QJA5SDDN-70753de7.js";const L={title:"RmgLabel",component:s},r=()=>e.jsx(s,{label:"Basic input",children:e.jsx(a,{})});var t,o,m;r.parameters={...r.parameters,docs:{...(t=r.parameters)==null?void 0:t.docs,source:{originalSource:`() => {
  return <RmgLabel label="Basic input">
            <RmgDebouncedInput />
        </RmgLabel>;
}`,...(m=(o=r.parameters)==null?void 0:o.docs)==null?void 0:m.source}}};const f=["Basic"];export{r as Basic,f as __namedExportsOrder,L as default};
//# sourceMappingURL=rmg-label.stories-41fd37f1.js.map
