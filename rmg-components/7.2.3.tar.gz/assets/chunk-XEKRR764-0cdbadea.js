import{c as r}from"./chunk-DEQZ7DVA-08ba7ba3.js";var o=r({d:"M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20v-2z",displayName:"ArrowBackIcon"}),c=r({d:"M12 4l-1.41 1.41L16.17 11H4v2h12.17l-5.58 5.59L12 20l8-8z",displayName:"ArrowForwardIcon"});export{o as A,c as a};
//# sourceMappingURL=chunk-XEKRR764-0cdbadea.js.map
