import{j as s}from"./jsx-runtime-4ca860c5.js";import{R as n}from"./rmg-multi-line-string-05ecb1a2.js";import"./index-61bf1805.js";import"./_commonjsHelpers-de833af9.js";import"./chunk-ZJJGQIVY-35f6fb8e.js";import"./emotion-use-insertion-effect-with-fallbacks.browser.esm-5b0f5dab.js";const u={title:"RmgMultiLineString",component:n},t=()=>{const o=`First line
Second line
Third line`;return s.jsx(n,{text:o,delimiter:`
`})};var e,r,i;t.parameters={...t.parameters,docs:{...(e=t.parameters)==null?void 0:e.docs,source:{originalSource:`() => {
  const text = 'First line\\nSecond line\\nThird line';
  return <RmgMultiLineString text={text} delimiter={'\\n'} />;
}`,...(i=(r=t.parameters)==null?void 0:r.docs)==null?void 0:i.source}}};const g=["Basic"];export{t as Basic,g as __namedExportsOrder,u as default};
//# sourceMappingURL=rmg-multi-line-string.stories-d1fd3be6.js.map
