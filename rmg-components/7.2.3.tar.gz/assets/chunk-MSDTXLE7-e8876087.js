import{r as a}from"./index-61bf1805.js";var l=({icon:e,color:t,size:o,...i})=>{const n=t||"currentColor",r=o||"14px";return a.createElement("span",{role:"img","aria-hidden":"true",style:{color:n,width:r,height:r,display:"inline-flex",fontSize:"inherit"},...i},e)};export{l as I};
//# sourceMappingURL=chunk-MSDTXLE7-e8876087.js.map
