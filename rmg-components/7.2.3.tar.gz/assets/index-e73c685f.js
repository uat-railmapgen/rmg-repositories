import{r as o}from"./index-61bf1805.js";var a=globalThis!=null&&globalThis.document?o.useLayoutEffect:o.useEffect;export{a as u};
//# sourceMappingURL=index-e73c685f.js.map
