var l=(()=>{let e;return typeof window<"u"?e=window:typeof globalThis<"u"?e=globalThis:typeof global<"u"?e=global:typeof self<"u"?e=self:e={},e})();export{l as s};
//# sourceMappingURL=index-d475d2ea.js.map
