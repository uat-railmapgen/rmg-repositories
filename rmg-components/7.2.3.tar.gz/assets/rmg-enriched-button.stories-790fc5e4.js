import{j as t}from"./jsx-runtime-4ca860c5.js";import{R as o}from"./rmg-enriched-button-3a34cbb6.js";import{H as m}from"./chunk-3ASUQ6PA-42e2c09a.js";import"./index-61bf1805.js";import"./_commonjsHelpers-de833af9.js";import"./chunk-ZJJGQIVY-35f6fb8e.js";import"./emotion-use-insertion-effect-with-fallbacks.browser.esm-5b0f5dab.js";import"./chunk-UVUR7MCU-7fc2c9bf.js";import"./index-6830816b.js";import"./emotion-react.browser.esm-3572b68e.js";import"./index-c23131f5.js";import"./index-23143ea6.js";const j={title:"RmgEnrichedButton",component:o},r=()=>t.jsxs(m,{children:[t.jsx(o,{variant:"solid",colorScheme:"primary",primaryText:"Project 123",secondaryText:"Last modified: 10 mins ago"}),t.jsx(o,{primaryText:"Kwun Tong Line",secondaryText:"by: wongchito"})]});var e,i,n;r.parameters={...r.parameters,docs:{...(e=r.parameters)==null?void 0:e.docs,source:{originalSource:`() => {
  return <HStack>
            <RmgEnrichedButton variant="solid" colorScheme="primary" primaryText="Project 123" secondaryText="Last modified: 10 mins ago" />
            <RmgEnrichedButton primaryText="Kwun Tong Line" secondaryText="by: wongchito" />
        </HStack>;
}`,...(n=(i=r.parameters)==null?void 0:i.docs)==null?void 0:n.source}}};const B=["Basic"];export{r as Basic,B as __namedExportsOrder,j as default};
//# sourceMappingURL=rmg-enriched-button.stories-790fc5e4.js.map
