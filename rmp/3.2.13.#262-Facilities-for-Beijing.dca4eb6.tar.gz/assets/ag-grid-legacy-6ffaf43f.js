System.register(["./react-legacy-9060605e.js"],(function(e,t){"use strict";return{setters:[null],execute:function(){}}}));
