System.register(["./react-legacy-J6S8G-Zx.js"],(function(e,t){"use strict";return{setters:[null],execute:function(){}}}));
