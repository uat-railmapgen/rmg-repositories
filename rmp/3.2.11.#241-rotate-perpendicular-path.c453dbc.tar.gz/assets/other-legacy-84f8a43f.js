System.register([],(function(e,t){"use strict";return{execute:function(){e("default",[{id:"other",name:{en:"Customise","zh-Hans":"自定义","zh-Hant":"自訂"},colour:"#aaaaaa"}])}}}));
