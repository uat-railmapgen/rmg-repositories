System.register(["./react-legacy-5e1577ad.js"],(function(e,t){"use strict";return{setters:[null],execute:function(){}}}));
