const a=[{id:"other",name:{en:"Customise","zh-Hans":"\u81EA\u5B9A\u4E49","zh-Hant":"\u81EA\u8A02"},colour:"#aaaaaa"}];export{a as default};
