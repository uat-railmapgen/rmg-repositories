import{_ as t}from"./iframe-fEM-XA4H.js";import"../sb-preview/runtime.js";var _={docs:{renderer:async()=>{let{DocsRenderer:r}=await t(()=>import("./DocsRenderer-NNNQARDV-IVDm_t3j.js").then(e=>e.D),__vite__mapDeps([0,1,2,3,4,5,6,7]));return new r}}};export{_ as parameters};
function __vite__mapDeps(indexes) {
  if (!__vite__mapDeps.viteFileDeps) {
    __vite__mapDeps.viteFileDeps = ["assets/DocsRenderer-NNNQARDV-IVDm_t3j.js","assets/iframe-fEM-XA4H.js","assets/index-XiNr8FW2.js","assets/_commonjsHelpers-5-cIlDoe.js","assets/react-18-8u3SsdfO.js","assets/index-ogXoivrg.js","assets/_getPrototype-4FkL748a.js","assets/index-PPLHz8o0.js"]
  }
  return indexes.map((i) => __vite__mapDeps.viteFileDeps[i])
}