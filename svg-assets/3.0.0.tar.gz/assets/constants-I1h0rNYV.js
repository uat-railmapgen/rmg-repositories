const o="#012639";export{o as N};
