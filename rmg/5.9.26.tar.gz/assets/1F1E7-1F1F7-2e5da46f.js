const s="/rmg/assets/1F1E7-1F1F7-17cdb7dc.svg";export{s as default};
