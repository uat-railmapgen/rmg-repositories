const F="/rmg/assets/1F1F3-1F1F4-98c24c78.svg";export{F as default};
