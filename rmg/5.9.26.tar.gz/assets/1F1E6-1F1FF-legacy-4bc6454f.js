System.register([],(function(e,t){"use strict";return{execute:function(){e("default","/rmg/assets/1F1E6-1F1FF-ed7c32f3.svg")}}}));
