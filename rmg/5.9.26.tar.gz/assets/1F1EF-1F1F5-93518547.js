const F="/rmg/assets/1F1EF-1F1F5-19ea77f9.svg";export{F as default};
