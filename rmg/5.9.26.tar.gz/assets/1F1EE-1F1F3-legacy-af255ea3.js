System.register([],(function(e,t){"use strict";return{execute:function(){e("default","/rmg/assets/1F1EE-1F1F3-eddbfd54.svg")}}}));
