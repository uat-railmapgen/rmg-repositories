const s="/rmg/assets/1F1E7-1F1EA-14c9eedd.svg";export{s as default};
