const s="/rmg/assets/1F1EE-1F1F9-746aa482.svg";export{s as default};
