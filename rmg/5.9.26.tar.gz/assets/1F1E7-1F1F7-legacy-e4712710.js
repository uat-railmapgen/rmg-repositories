System.register([],(function(e,t){"use strict";return{execute:function(){e("default","/rmg/assets/1F1E7-1F1F7-17cdb7dc.svg")}}}));
