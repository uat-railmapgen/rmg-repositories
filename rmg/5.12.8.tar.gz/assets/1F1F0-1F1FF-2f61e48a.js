const F="/rmg/assets/1F1F0-1F1FF-71f4562c.svg";export{F as default};
