const s="/rmg/assets/1F1EE-1F1E9-85abd081.svg";export{s as default};
