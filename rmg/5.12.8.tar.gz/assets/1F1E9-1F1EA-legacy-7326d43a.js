System.register([],(function(e,t){"use strict";return{execute:function(){e("default","/rmg/assets/1F1E9-1F1EA-41e2d64e.svg")}}}));
