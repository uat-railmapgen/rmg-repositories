const F="/rmg/assets/1F1F0-1F1F7-c704905a.svg";export{F as default};
