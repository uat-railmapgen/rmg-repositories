const F="/rmg/assets/1F1FA-1F1F8-87a9213b.svg";export{F as default};
