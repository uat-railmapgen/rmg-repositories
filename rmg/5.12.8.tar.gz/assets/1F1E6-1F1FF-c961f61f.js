const F="/rmg/assets/1F1E6-1F1FF-ed7c32f3.svg";export{F as default};
