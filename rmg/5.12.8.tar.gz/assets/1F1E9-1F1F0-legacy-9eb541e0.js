System.register([],(function(e,t){"use strict";return{execute:function(){e("default","/rmg/assets/1F1E9-1F1F0-8f687b1f.svg")}}}));
