System.register([],(function(e,t){"use strict";return{execute:function(){e("default","/rmg/assets/1F1FA-1F1FF-9dee758c.svg")}}}));
