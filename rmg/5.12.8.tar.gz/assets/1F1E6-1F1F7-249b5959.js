const s="/rmg/assets/1F1E6-1F1F7-209ffa2c.svg";export{s as default};
