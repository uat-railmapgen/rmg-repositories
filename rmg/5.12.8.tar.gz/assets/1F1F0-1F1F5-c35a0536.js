const F="/rmg/assets/1F1F0-1F1F5-914b49f3.svg";export{F as default};
