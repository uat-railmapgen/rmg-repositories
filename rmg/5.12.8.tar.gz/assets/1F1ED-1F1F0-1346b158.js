const s="/rmg/assets/1F1ED-1F1F0-d0dd2703.svg";export{s as default};
