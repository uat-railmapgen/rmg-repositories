System.register([],(function(e,t){"use strict";return{execute:function(){e("default","/rmg/assets/1F1EC-1F1F7-ff8d2e51.svg")}}}));
