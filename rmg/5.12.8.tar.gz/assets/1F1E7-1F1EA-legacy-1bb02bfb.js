System.register([],(function(e,t){"use strict";return{execute:function(){e("default","/rmg/assets/1F1E7-1F1EA-14c9eedd.svg")}}}));
