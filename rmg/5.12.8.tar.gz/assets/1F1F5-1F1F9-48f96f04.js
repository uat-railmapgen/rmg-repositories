const F="/rmg/assets/1F1F5-1F1F9-fd255fc5.svg";export{F as default};
