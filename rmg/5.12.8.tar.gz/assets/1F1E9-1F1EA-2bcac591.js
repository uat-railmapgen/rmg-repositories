const s="/rmg/assets/1F1E9-1F1EA-41e2d64e.svg";export{s as default};
