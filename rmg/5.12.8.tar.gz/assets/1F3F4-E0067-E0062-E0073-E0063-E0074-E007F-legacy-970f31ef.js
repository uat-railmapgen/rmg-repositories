System.register([],(function(e,t){"use strict";return{execute:function(){e("default","/rmg/assets/1F3F4-E0067-E0062-E0073-E0063-E0074-E007F-57419778.svg")}}}));
