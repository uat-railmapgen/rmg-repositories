System.register([],(function(e,t){"use strict";return{execute:function(){e("default","/rmg/assets/1F1EE-1F1F9-746aa482.svg")}}}));
