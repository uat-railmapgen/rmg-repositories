const s="/rmg/assets/1F1EA-1F1F8-85185621.svg";export{s as default};
