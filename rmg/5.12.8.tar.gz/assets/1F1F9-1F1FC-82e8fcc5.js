const F="/rmg/assets/1F1F9-1F1FC-96d87ac7.svg";export{F as default};
