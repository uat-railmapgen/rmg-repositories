const s="/rmg/assets/1F1F5-1F1EA-df6ca1b3.svg";export{s as default};
