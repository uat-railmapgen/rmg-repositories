const s="/rmg/assets/1F1F5-1F1E6-faca42cb.svg";export{s as default};
