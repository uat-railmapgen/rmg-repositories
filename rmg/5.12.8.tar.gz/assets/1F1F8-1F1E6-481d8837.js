const s="/rmg/assets/1F1F8-1F1E6-d99f8b6d.svg";export{s as default};
