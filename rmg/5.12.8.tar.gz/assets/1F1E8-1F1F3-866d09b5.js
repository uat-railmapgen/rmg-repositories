const s="/rmg/assets/1F1E8-1F1F3-113ccc2a.svg";export{s as default};
