const F="/rmg/assets/1F1F5-1F1F0-2eedf010.svg";export{F as default};
