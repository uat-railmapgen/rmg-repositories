System.register([],(function(e,t){"use strict";return{execute:function(){e("default","/rmg/assets/1F1ED-1F1FA-0a297b87.svg")}}}));
