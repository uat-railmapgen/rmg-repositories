const s="/rmg/assets/1F1FA-1F1E6-af3ddf57.svg";export{s as default};
