const F="/rmg/assets/1F1F3-1F1F1-cf462640.svg";export{F as default};
