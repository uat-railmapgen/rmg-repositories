System.register([],(function(e,t){"use strict";return{execute:function(){e("default","/rmg/assets/1F1EB-1F1F7-210ca280.svg")}}}));
