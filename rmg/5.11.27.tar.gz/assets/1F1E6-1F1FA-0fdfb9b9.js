const s="/rmg/assets/1F1E6-1F1FA-5ef73237.svg";export{s as default};
