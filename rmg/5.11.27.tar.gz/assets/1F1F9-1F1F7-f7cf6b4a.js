const F="/rmg/assets/1F1F9-1F1F7-a4b194f8.svg";export{F as default};
