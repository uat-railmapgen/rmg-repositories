System.register([],(function(e,t){"use strict";return{execute:function(){e("default","/rmg/assets/1F1F0-1F1FF-71f4562c.svg")}}}));
