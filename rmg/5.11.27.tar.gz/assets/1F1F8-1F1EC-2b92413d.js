const s="/rmg/assets/1F1F8-1F1EC-fb4188e3.svg";export{s as default};
