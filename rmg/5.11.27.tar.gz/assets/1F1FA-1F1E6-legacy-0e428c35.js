System.register([],(function(e,t){"use strict";return{execute:function(){e("default","/rmg/assets/1F1FA-1F1E6-af3ddf57.svg")}}}));
