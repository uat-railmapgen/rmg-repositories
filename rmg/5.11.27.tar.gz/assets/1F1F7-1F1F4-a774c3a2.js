const F="/rmg/assets/1F1F7-1F1F4-ca9fdf80.svg";export{F as default};
