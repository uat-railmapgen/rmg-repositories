const s="/rmg/assets/1F1FB-1F1EA-b95a4ae9.svg";export{s as default};
