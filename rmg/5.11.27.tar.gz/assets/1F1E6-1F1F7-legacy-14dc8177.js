System.register([],(function(e,t){"use strict";return{execute:function(){e("default","/rmg/assets/1F1E6-1F1F7-209ffa2c.svg")}}}));
