const s="/rmg/assets/1F1EE-1F1F7-b43a6d7e.svg";export{s as default};
