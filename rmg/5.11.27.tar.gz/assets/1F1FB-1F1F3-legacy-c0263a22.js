System.register([],(function(e,t){"use strict";return{execute:function(){e("default","/rmg/assets/1F1FB-1F1F3-26768257.svg")}}}));
