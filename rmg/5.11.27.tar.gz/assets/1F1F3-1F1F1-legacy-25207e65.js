System.register([],(function(e,t){"use strict";return{execute:function(){e("default","/rmg/assets/1F1F3-1F1F1-cf462640.svg")}}}));
