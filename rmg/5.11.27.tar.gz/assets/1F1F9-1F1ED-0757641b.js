const s="/rmg/assets/1F1F9-1F1ED-93c8b800.svg";export{s as default};
