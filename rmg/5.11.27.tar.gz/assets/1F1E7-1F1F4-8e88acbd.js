const s="/rmg/assets/1F1E7-1F1F4-fc10dd32.svg";export{s as default};
