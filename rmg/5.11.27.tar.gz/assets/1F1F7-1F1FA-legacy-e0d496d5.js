System.register([],(function(e,t){"use strict";return{execute:function(){e("default","/rmg/assets/1F1F7-1F1FA-af6020d5.svg")}}}));
