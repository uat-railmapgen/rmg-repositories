System.register([],(function(e,t){"use strict";return{execute:function(){e("default","/rmg/assets/1F1F0-1F1F5-914b49f3.svg")}}}));
