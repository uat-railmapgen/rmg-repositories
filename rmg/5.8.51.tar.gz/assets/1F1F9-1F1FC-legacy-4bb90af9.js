System.register([],(function(e,t){"use strict";return{execute:function(){e("default","/rmg/assets/1F1F9-1F1FC-96d87ac7.svg")}}}));
