const s="/rmg/assets/1F1ED-1F1FA-0a297b87.svg";export{s as default};
