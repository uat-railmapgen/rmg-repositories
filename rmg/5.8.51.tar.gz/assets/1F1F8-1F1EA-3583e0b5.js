const s="/rmg/assets/1F1F8-1F1EA-971614aa.svg";export{s as default};
