System.register([],(function(e,t){"use strict";return{execute:function(){e("default","/rmg/assets/1F1FB-1F1EA-b95a4ae9.svg")}}}));
