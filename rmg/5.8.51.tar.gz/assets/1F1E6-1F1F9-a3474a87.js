const s="/rmg/assets/1F1E6-1F1F9-1c14cd89.svg";export{s as default};
