System.register([],(function(e,t){"use strict";return{execute:function(){e("default","/rmg/assets/1F1EA-1F1F8-85185621.svg")}}}));
