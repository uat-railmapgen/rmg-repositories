const E="/rmg/assets/1F3F4-E0067-E0062-E0073-E0063-E0074-E007F-57419778.svg";export{E as default};
