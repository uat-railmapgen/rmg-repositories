const F="/rmg/assets/1F1F2-1F1FD-33d615b0.svg";export{F as default};
