const F="/rmg/assets/1F1F7-1F1FA-af6020d5.svg";export{F as default};
