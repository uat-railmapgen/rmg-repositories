const s="/rmg/assets/1F1E9-1F1F0-8f687b1f.svg";export{s as default};
