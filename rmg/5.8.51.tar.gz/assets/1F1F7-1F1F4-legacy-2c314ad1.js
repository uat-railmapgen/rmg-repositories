System.register([],(function(e,t){"use strict";return{execute:function(){e("default","/rmg/assets/1F1F7-1F1F4-ca9fdf80.svg")}}}));
