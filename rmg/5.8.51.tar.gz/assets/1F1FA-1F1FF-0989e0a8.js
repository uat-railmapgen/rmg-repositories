const F="/rmg/assets/1F1FA-1F1FF-9dee758c.svg";export{F as default};
