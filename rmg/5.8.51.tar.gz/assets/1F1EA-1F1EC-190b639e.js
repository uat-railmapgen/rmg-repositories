const s="/rmg/assets/1F1EA-1F1EC-cfee03ff.svg";export{s as default};
