import{Z as o}from"./vendor-95248b7d.js";const a=[{id:"sx1",colour:"#c5003e",fg:o.white,name:{en:"Line 1","zh-Hans":"1号线","zh-Hant":"1號線"}}];export{a as default};
