const s="/rmg/assets/1F1E8-1F1E6-02984d5c.svg";export{s as default};
