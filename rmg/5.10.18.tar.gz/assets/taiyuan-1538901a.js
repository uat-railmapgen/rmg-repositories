import{P as o}from"./vendor-89fa957a.js";const n=[{id:"2",colour:"#b31c21",fg:o.white,name:{en:"Line 2","zh-Hans":"2号线","zh-Hant":"2號線"}}];export{n as default};
