const F="/rmg/assets/1F1FA-1F1F3-1f87bc41.svg";export{F as default};
