System.register([],(function(e,t){"use strict";return{execute:function(){e("default","/rmg/assets/1F1F5-1F1F9-fd255fc5.svg")}}}));
