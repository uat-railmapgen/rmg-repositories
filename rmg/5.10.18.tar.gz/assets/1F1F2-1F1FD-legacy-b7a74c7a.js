System.register([],(function(e,t){"use strict";return{execute:function(){e("default","/rmg/assets/1F1F2-1F1FD-33d615b0.svg")}}}));
