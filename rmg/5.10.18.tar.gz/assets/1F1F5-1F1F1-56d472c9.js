const F="/rmg/assets/1F1F5-1F1F1-23f9861b.svg";export{F as default};
