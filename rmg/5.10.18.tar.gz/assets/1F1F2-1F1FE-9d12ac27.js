const F="/rmg/assets/1F1F2-1F1FE-e8bbf51c.svg";export{F as default};
