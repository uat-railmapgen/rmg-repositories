System.register([],(function(e,t){"use strict";return{execute:function(){e("default","/rmg/assets/1F1ED-1F1F0-d0dd2703.svg")}}}));
