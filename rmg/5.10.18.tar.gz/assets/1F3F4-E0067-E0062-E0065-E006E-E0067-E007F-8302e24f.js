const E="/rmg/assets/1F3F4-E0067-E0062-E0065-E006E-E0067-E007F-7d4df867.svg";export{E as default};
