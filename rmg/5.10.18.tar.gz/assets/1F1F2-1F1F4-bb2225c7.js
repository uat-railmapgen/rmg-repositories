const F="/rmg/assets/1F1F2-1F1F4-18731367.svg";export{F as default};
