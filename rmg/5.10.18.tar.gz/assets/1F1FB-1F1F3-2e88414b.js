const F="/rmg/assets/1F1FB-1F1F3-26768257.svg";export{F as default};
