System.register([],(function(e,t){"use strict";return{execute:function(){e("default","/rmg/assets/1F1F9-1F1ED-93c8b800.svg")}}}));
