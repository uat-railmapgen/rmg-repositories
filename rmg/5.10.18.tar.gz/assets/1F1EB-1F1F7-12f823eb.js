const s="/rmg/assets/1F1EB-1F1F7-210ca280.svg";export{s as default};
