const s="/rmg/assets/1F1EE-1F1EA-345b9875.svg";export{s as default};
