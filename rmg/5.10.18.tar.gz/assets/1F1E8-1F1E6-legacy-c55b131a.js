System.register([],(function(e,t){"use strict";return{execute:function(){e("default","/rmg/assets/1F1E8-1F1E6-02984d5c.svg")}}}));
